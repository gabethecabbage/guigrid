#! /bin/bash
rm /bin/gbsgrid
rm /usr/share/applications/gbsgrid.desktop
rm -R ../gbsgrid

